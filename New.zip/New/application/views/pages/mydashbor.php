
<div class='container' style="margin-top:220px;">
	<div class='col-md-3'>
		<?php
			$this->load->view('pages/sidemydashbor');
		?>
	
	</div>
	<div class='col-md-9'>
		<h3>My Dashboard</h3>
	</div>
</div>
<?php $this->load->view('pages/footer');?>